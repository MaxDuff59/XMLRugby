from xmlrugby import extract
