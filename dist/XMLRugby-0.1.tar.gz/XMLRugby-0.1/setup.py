from setuptools import setup, find_packages

setup(
    name='XMLRugby',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'numpy'
        # Any other dependencies you have
    ],
)
